# Gravity 0.7
## controls
<table>
<tr><th>key</th><th>action</th></tr>
<tr><td>left or right</td><td>the angular acceleration of the wheel</td></tr>
<tr><td>space</td><td>stop the wheel</td></tr>
<tr><td>D</td><td>logoff</td></tr>
<tr><td>esc</td><td>menu</td></tr>
</table>

## links
<pre>
https://github.com/adler3d/demos/tree/master/Gravity
http://igdc.ru/project.php?id=156
http://igdc.ru/igdc_top.php?&konkurs=34
</pre>

<img src="img.png">

## IGDC.RU 49 Rocket Arena

This is work for contest on IGDC.  
archive: http://igdc.ru/konkurses/rocket_arena.zip

## GameScr.PNG
<img src="GameScr.PNG">

## Graph.PNG
<img src="Graph.PNG">

## Video
https://youtu.be/g_hpEOwxEDM
